---
permalink: /
title: "Hi, I'm Apil"
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

I am Apil K C, a Ph.D. scholar in Urban Planning with a professional background in architecture and urban planning, with a focus on resilient planning practices. My core interest lies in bridging planning decisions with the lived realities of people — ensuring that the choices we make in planning truly matter to those they affect.

I'm also making this website while learning to use github so bear with me. 

If you want to meet me over zoom, let's schedule our next meet here. 
<a href="https://calendar.app.google/oZRpq7Eaf6Jkj6iU8" class="btn btn--info" target="_blank">
  <i class="fas fa-calendar-alt"></i> Let's Schedule
</a>

Thank you. 
